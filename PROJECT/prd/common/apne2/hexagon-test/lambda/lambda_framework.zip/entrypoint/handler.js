try {
    module.exports = require('/opt/out/handler.js');
} catch (e) {
    console.error(e);
    throw e;
}
